# Step 8 — Deploy BizMoney to Private Cloud Staging

This folder is configured for a simple Render staging deployment:

Browser
→ BizMoney Next.js frontend
→ internal proxy
→ FastAPI backend
→ managed PostgreSQL

The browser calls `/api/...` on the same frontend origin. Next.js forwards those calls to the backend over Render networking. This keeps the browser configuration simple and works with BizMoney's HttpOnly session-cookie approach.

## What you need

1. A GitHub repository containing this project.
2. A Render account.
3. An OpenAI API key only when you are ready to switch the AI provider from the local parser to OpenAI.

Do not commit API keys, database passwords, or JWT secrets to GitHub.

## A. Put the project in GitHub

Create a new private repository, for example:

`bizmoney-tracker`

Upload/push the full contents of this Step 8 folder so `render.yaml` is at the repository root.

## B. Create the Render Blueprint

In Render:

1. Create a new Blueprint.
2. Connect the GitHub repository.
3. Render will detect `render.yaml`.
4. Review the three resources:
   - `bizmoney-frontend-staging`
   - `bizmoney-backend-staging`
   - `bizmoney-postgres-staging`
5. When Render asks for `OPENAI_API_KEY`, you may leave AI in local mode initially. If a value is required by the creation UI, add your real server-side key; never place it in frontend variables.
6. Apply the Blueprint.

The backend start command runs:

`alembic upgrade head`

before starting FastAPI, so the database schema is created/updated during the staging start.

## C. First staging checks

After deployment:

1. Open the frontend's Render URL.
2. Create a fresh test account.
3. Create a test business.
4. Add KSh 5,000 income.
5. Add KSh 1,500 expense.
6. Confirm dashboard profit is KSh 3,500.
7. Sign out and sign back in.
8. Confirm the transactions remain.
9. Try the BizMoney AI Assistant in local mode.
10. Confirm an AI proposal does not change dashboard totals until you explicitly confirm it.

Use test data only during initial staging.

## D. Enable OpenAI later

Backend environment:

`AI_PROVIDER=openai`

`OPENAI_API_KEY=<secret>`

`OPENAI_MODEL=<supported model>`

Redeploy the backend after changing environment variables.

The OpenAI key belongs only on the backend.

## E. HTTPS and cookies

Render web services receive HTTPS URLs. For staging, keep:

`COOKIE_SECURE=true`

BizMoney's session cookie is HttpOnly. The frontend uses same-origin `/api` requests and proxies them to the backend.

## F. Managed PostgreSQL and backups

The Blueprint creates a Render PostgreSQL database.

For a serious staging or production environment, use a database plan that includes the backup/recovery guarantees you require. Do not rely on an ephemeral application filesystem for financial records.

## G. Custom domain later

You do not need a custom domain to test staging. The generated Render URL is enough.

Later you can use a domain such as:

`app.bizmoney.co.ke`

or another name you own.

Before changing domains, update the deployment environment and retest cookies, CORS, redirects and HTTPS.

## H. Staging security checklist

Before inviting outside customers:

- Keep the repository private.
- Use HTTPS only.
- Keep `COOKIE_SECURE=true`.
- Never expose `DATABASE_URL`, `JWT_SECRET`, or `OPENAI_API_KEY` to the frontend.
- Enable database backups.
- Add email verification.
- Add password reset.
- Add login rate limiting.
- Add audit logging.
- Add monitoring/error alerts.
- Add dependency/security scanning.
- Add terms of service and privacy policy.
- Test data isolation between two separate accounts.
- Test database restore procedures.

## I. Important limitation

This package prepares BizMoney for deployment, but creating the live Render and GitHub resources requires access to your accounts. The project itself does not contain account credentials.

Once GitHub is connected, subsequent code changes can use the normal repository → Render deployment workflow.
