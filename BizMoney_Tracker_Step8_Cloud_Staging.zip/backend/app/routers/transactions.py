from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..access import require_business_access
from ..database import get_db
from ..models import Category, Transaction, User
from ..schemas import TransactionCreate, TransactionOut
from ..security import csrf_protect, current_user

router = APIRouter(prefix="/api/transactions", tags=["Transactions"])

@router.post("", response_model=TransactionOut, dependencies=[Depends(csrf_protect)])
def create_transaction(
    data: TransactionCreate,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    require_business_access(db, data.business_id, user.id)

    if data.transaction_type not in {"INCOME", "EXPENSE"}:
        raise HTTPException(400, "transaction_type must be INCOME or EXPENSE")

    category = db.get(Category, data.category_id)
    if not category or category.business_id != data.business_id or category.status != "active":
        raise HTTPException(400, "Invalid category for this business")

    if category.type != data.transaction_type:
        raise HTTPException(
            400,
            f"Category type {category.type} does not match transaction type {data.transaction_type}"
        )

    if data.source not in {"MANUAL", "AI_TEXT", "AI_VOICE", "RECEIPT", "IMPORT"}:
        raise HTTPException(400, "Invalid transaction source")

    tx = Transaction(
        **data.model_dump(),
        created_by=user.id,
        status="CONFIRMED",
    )
    db.add(tx)
    db.commit()
    db.refresh(tx)
    return tx

@router.get("", response_model=list[TransactionOut])
def list_transactions(
    business_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    require_business_access(db, business_id, user.id)

    return db.scalars(
        select(Transaction)
        .where(Transaction.business_id == business_id)
        .order_by(Transaction.transaction_date.desc(), Transaction.id.desc())
    ).all()
