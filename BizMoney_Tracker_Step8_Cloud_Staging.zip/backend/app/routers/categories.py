from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..access import require_business_access
from ..database import get_db
from ..models import Category, User
from ..schemas import CategoryOut
from ..security import current_user

router = APIRouter(prefix="/api/categories", tags=["Categories"])

@router.get("", response_model=list[CategoryOut])
def list_categories(
    business_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    require_business_access(db, business_id, user.id)

    return db.scalars(
        select(Category)
        .where(
            Category.business_id == business_id,
            Category.status == "active",
        )
        .order_by(Category.type, Category.name)
    ).all()
