from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Business, BusinessMember, Category, User
from ..schemas import BusinessCreate, BusinessOut
from ..security import csrf_protect, current_user

router = APIRouter(prefix="/api/businesses", tags=["Businesses"])

DEFAULTS = [
    ("Sales", "INCOME"),
    ("Service Income", "INCOME"),
    ("Other Income", "INCOME"),
    ("Stock", "EXPENSE"),
    ("Rent", "EXPENSE"),
    ("Transport", "EXPENSE"),
    ("Electricity", "EXPENSE"),
    ("Water", "EXPENSE"),
    ("Internet", "EXPENSE"),
    ("Airtime", "EXPENSE"),
    ("Salaries", "EXPENSE"),
    ("Marketing", "EXPENSE"),
    ("Repairs", "EXPENSE"),
    ("Supplies", "EXPENSE"),
    ("Bank Charges", "EXPENSE"),
    ("Other Expenses", "EXPENSE"),
]

@router.post("", response_model=BusinessOut, dependencies=[Depends(csrf_protect)])
def create_business(
    data: BusinessCreate,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    business = Business(owner_id=user.id, **data.model_dump())
    db.add(business)
    db.flush()

    db.add(BusinessMember(
        business_id=business.id,
        user_id=user.id,
        role="OWNER",
        status="active",
    ))

    for name, category_type in DEFAULTS:
        db.add(Category(
            business_id=business.id,
            name=name,
            type=category_type,
            is_default=True,
            status="active",
        ))

    db.commit()
    db.refresh(business)
    return business

@router.get("", response_model=list[BusinessOut])
def list_businesses(
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    return db.scalars(
        select(Business)
        .join(BusinessMember, BusinessMember.business_id == Business.id)
        .where(
            BusinessMember.user_id == user.id,
            BusinessMember.status == "active",
        )
        .order_by(Business.business_name)
    ).all()
