from decimal import Decimal

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..access import require_business_access
from ..database import get_db
from ..models import Transaction, User
from ..schemas import DashboardOut
from ..security import current_user

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])

@router.get("", response_model=DashboardOut)
def dashboard(
    business_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    require_business_access(db, business_id, user.id)

    sales = db.scalar(
        select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.business_id == business_id,
            Transaction.transaction_type == "INCOME",
            Transaction.status == "CONFIRMED",
        )
    )

    expenses = db.scalar(
        select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.business_id == business_id,
            Transaction.transaction_type == "EXPENSE",
            Transaction.status == "CONFIRMED",
        )
    )

    sales = Decimal(sales or 0)
    expenses = Decimal(expenses or 0)

    return DashboardOut(
        total_sales=sales,
        total_expenses=expenses,
        net_profit=sales - expenses,
        cash_flow=sales - expenses,
    )
