from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db, settings
from ..models import User
from ..schemas import RegisterIn, LoginIn, AuthOut, MeOut
from ..security import (
    COOKIE_NAME, CSRF_COOKIE_NAME, create_token, current_user,
    hash_password, new_csrf_token, verify_password
)

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

def set_auth_cookies(response: Response, user_id: int):
    token = create_token(user_id)
    csrf = new_csrf_token()

    response.set_cookie(
        COOKIE_NAME,
        token,
        httponly=True,
        secure=settings.cookie_secure,
        samesite=settings.cookie_samesite,
        max_age=settings.access_token_minutes * 60,
        path="/",
    )

    response.set_cookie(
        CSRF_COOKIE_NAME,
        csrf,
        httponly=False,
        secure=settings.cookie_secure,
        samesite=settings.cookie_samesite,
        max_age=settings.access_token_minutes * 60,
        path="/",
    )

@router.post("/register", response_model=AuthOut)
def register(data: RegisterIn, response: Response, db: Session = Depends(get_db)):
    email = data.email.lower().strip()

    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "Email is already registered")

    user = User(
        full_name=data.full_name.strip(),
        email=email,
        password_hash=hash_password(data.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    set_auth_cookies(response, user.id)
    return AuthOut()

@router.post("/login", response_model=AuthOut)
def login(data: LoginIn, response: Response, db: Session = Depends(get_db)):
    email = data.email.lower().strip()
    user = db.scalar(select(User).where(User.email == email))

    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")

    set_auth_cookies(response, user.id)
    return AuthOut()

@router.post("/logout", response_model=AuthOut)
def logout(response: Response):
    response.delete_cookie(COOKIE_NAME, path="/")
    response.delete_cookie(CSRF_COOKIE_NAME, path="/")
    return AuthOut(authenticated=False)

@router.get("/me", response_model=MeOut)
def me(user: User = Depends(current_user)):
    return user
