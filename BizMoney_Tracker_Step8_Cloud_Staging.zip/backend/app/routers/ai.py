from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..access import require_business_access
from ..ai_service import parse_transaction_message
from ..database import get_db
from ..models import AITransactionProposal, Category, Transaction, User
from ..security import csrf_protect, current_user

router = APIRouter(prefix="/api/ai", tags=["AI Assistant"])


class AIMessageIn(BaseModel):
    business_id: int
    message: str = Field(min_length=2, max_length=1200)


class ProposalOut(BaseModel):
    id: int
    business_id: int
    transaction_type: str
    amount: Decimal | None
    category_id: int | None
    category_name: str | None = None
    transaction_date: date | None
    description: str
    payment_method: str | None
    confidence: Decimal | None
    status: str
    needs_clarification: bool = False
    clarification_question: str | None = None


class ConfirmOut(BaseModel):
    proposal_id: int
    transaction_id: int
    status: str = "CONFIRMED"


@router.post("/proposals", response_model=ProposalOut, dependencies=[Depends(csrf_protect)])
def create_proposal(
    data: AIMessageIn,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    require_business_access(db, data.business_id, user.id)

    try:
        parsed = parse_transaction_message(data.message, db, data.business_id)
    except Exception as exc:
        raise HTTPException(502, f"AI parsing failed: {str(exc)[:180]}")

    category = None
    category_name = parsed.get("category_name")
    if category_name:
        category = db.scalar(select(Category).where(
            Category.business_id == data.business_id,
            Category.name == category_name,
            Category.status == "active",
        ))

    amount = parsed.get("amount")
    try:
        amount_value = Decimal(str(amount)) if amount not in (None, "") else None
    except Exception:
        amount_value = None

    try:
        tx_date = date.fromisoformat(parsed.get("transaction_date"))
    except Exception:
        tx_date = date.today()

    proposal = AITransactionProposal(
        business_id=data.business_id,
        user_id=user.id,
        transaction_type=parsed.get("transaction_type", "EXPENSE"),
        amount=amount_value,
        category_id=category.id if category else None,
        transaction_date=tx_date,
        description=(parsed.get("description") or data.message)[:500],
        payment_method=parsed.get("payment_method"),
        confidence=Decimal(str(parsed.get("confidence", 0))),
        status="PENDING",
    )
    db.add(proposal)
    db.commit()
    db.refresh(proposal)

    needs = bool(parsed.get("needs_clarification")) or proposal.amount is None or proposal.category_id is None
    question = parsed.get("clarification_question")
    if proposal.category_id is None and not question:
        question = "Which category should I use for this transaction?"

    return ProposalOut(
        id=proposal.id,
        business_id=proposal.business_id,
        transaction_type=proposal.transaction_type,
        amount=proposal.amount,
        category_id=proposal.category_id,
        category_name=category.name if category else None,
        transaction_date=proposal.transaction_date,
        description=proposal.description,
        payment_method=proposal.payment_method,
        confidence=proposal.confidence,
        status=proposal.status,
        needs_clarification=needs,
        clarification_question=question,
    )


@router.post("/proposals/{proposal_id}/confirm", response_model=ConfirmOut, dependencies=[Depends(csrf_protect)])
def confirm_proposal(
    proposal_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    proposal = db.get(AITransactionProposal, proposal_id)
    if not proposal:
        raise HTTPException(404, "Proposal not found")

    require_business_access(db, proposal.business_id, user.id)
    if proposal.user_id != user.id:
        raise HTTPException(403, "You cannot confirm another user's proposal")
    if proposal.status != "PENDING":
        raise HTTPException(409, "Proposal has already been handled")
    if proposal.amount is None or proposal.category_id is None or proposal.transaction_date is None:
        raise HTTPException(400, "Proposal is incomplete and cannot be confirmed")

    category = db.get(Category, proposal.category_id)
    if not category or category.business_id != proposal.business_id:
        raise HTTPException(400, "Proposal category is invalid")
    if category.type != proposal.transaction_type:
        raise HTTPException(400, "Proposal category does not match transaction type")

    tx = Transaction(
        business_id=proposal.business_id,
        category_id=proposal.category_id,
        created_by=user.id,
        transaction_type=proposal.transaction_type,
        amount=proposal.amount,
        transaction_date=proposal.transaction_date,
        description=proposal.description,
        payment_method=proposal.payment_method,
        status="CONFIRMED",
        source="AI_TEXT",
    )
    db.add(tx)
    proposal.status = "CONFIRMED"
    db.commit()
    db.refresh(tx)

    return ConfirmOut(proposal_id=proposal.id, transaction_id=tx.id)


@router.post("/proposals/{proposal_id}/reject", dependencies=[Depends(csrf_protect)])
def reject_proposal(
    proposal_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    proposal = db.get(AITransactionProposal, proposal_id)
    if not proposal:
        raise HTTPException(404, "Proposal not found")
    require_business_access(db, proposal.business_id, user.id)
    if proposal.user_id != user.id:
        raise HTTPException(403, "You cannot reject another user's proposal")
    if proposal.status != "PENDING":
        raise HTTPException(409, "Proposal has already been handled")
    proposal.status = "REJECTED"
    db.commit()
    return {"status": "REJECTED", "proposal_id": proposal.id}
