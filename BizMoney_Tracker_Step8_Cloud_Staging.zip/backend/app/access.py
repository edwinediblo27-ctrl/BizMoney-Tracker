from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import BusinessMember

def require_business_access(db: Session, business_id: int, user_id: int) -> BusinessMember:
    membership = db.scalar(
        select(BusinessMember).where(
            BusinessMember.business_id == business_id,
            BusinessMember.user_id == user_id,
            BusinessMember.status == "active",
        )
    )
    if not membership:
        raise HTTPException(403, "You do not have access to this business")
    return membership
