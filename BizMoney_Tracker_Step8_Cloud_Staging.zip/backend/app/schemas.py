from datetime import date
from decimal import Decimal
from pydantic import BaseModel, EmailStr, Field

class RegisterIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=160)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class AuthOut(BaseModel):
    authenticated: bool = True

class MeOut(BaseModel):
    id: int
    full_name: str
    email: EmailStr
    model_config = {"from_attributes": True}

class BusinessCreate(BaseModel):
    business_name: str = Field(min_length=2, max_length=200)
    business_type: str = "Retail"
    country: str = "Kenya"
    currency: str = "KES"

class BusinessOut(BusinessCreate):
    id: int
    owner_id: int
    model_config = {"from_attributes": True}

class CategoryOut(BaseModel):
    id: int
    business_id: int
    name: str
    type: str
    is_default: bool
    status: str
    model_config = {"from_attributes": True}

class TransactionCreate(BaseModel):
    business_id: int
    category_id: int
    transaction_type: str
    amount: Decimal = Field(gt=0, max_digits=15, decimal_places=2)
    transaction_date: date
    description: str = Field(default="", max_length=1000)
    payment_method: str | None = Field(default=None, max_length=40)
    source: str = "MANUAL"

class TransactionOut(TransactionCreate):
    id: int
    status: str
    created_by: int
    model_config = {"from_attributes": True}

class DashboardOut(BaseModel):
    total_sales: Decimal
    total_expenses: Decimal
    net_profit: Decimal
    cash_flow: Decimal
