import secrets
from datetime import datetime, timedelta, timezone

from fastapi import Cookie, Depends, Header, HTTPException, status
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from .database import get_db, settings
from .models import User

pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
COOKIE_NAME = "bizmoney_session"
CSRF_COOKIE_NAME = "bizmoney_csrf"

def hash_password(password: str) -> str:
    return pwd.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    return pwd.verify(password, hashed)

def create_token(user_id: int) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=settings.access_token_minutes)
    return jwt.encode({"sub": str(user_id), "exp": exp}, settings.jwt_secret, algorithm="HS256")

def new_csrf_token() -> str:
    return secrets.token_urlsafe(32)

def current_user(
    bizmoney_session: str | None = Cookie(default=None),
    db: Session = Depends(get_db),
) -> User:
    if not bizmoney_session:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    try:
        payload = jwt.decode(bizmoney_session, settings.jwt_secret, algorithms=["HS256"])
        user_id = int(payload["sub"])
    except (JWTError, KeyError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired session")

    user = db.get(User, user_id)
    if not user or user.status != "active":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid account")

    return user

def csrf_protect(
    x_csrf_token: str | None = Header(default=None),
    bizmoney_csrf: str | None = Cookie(default=None),
):
    if not x_csrf_token or not bizmoney_csrf:
        raise HTTPException(status_code=403, detail="Missing CSRF token")
    if not secrets.compare_digest(x_csrf_token, bizmoney_csrf):
        raise HTTPException(status_code=403, detail="Invalid CSRF token")
