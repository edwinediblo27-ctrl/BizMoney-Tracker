from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import settings
from .routers import ai, auth, businesses, categories, dashboard, transactions

app = FastAPI(
    title="BizMoney Tracker API",
    version="0.4.0",
    description="Staging-ready BizMoney Tracker backend foundation.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "X-CSRF-Token"],
)

app.include_router(auth.router)
app.include_router(ai.router)
app.include_router(businesses.router)
app.include_router(categories.router)
app.include_router(transactions.router)
app.include_router(dashboard.router)

@app.get("/health")
def health():
    return {"status": "ok", "service": "bizmoney-api", "version": "0.4.0"}
