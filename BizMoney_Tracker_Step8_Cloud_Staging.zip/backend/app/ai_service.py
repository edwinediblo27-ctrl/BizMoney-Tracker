import json
import re
from datetime import date
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .database import settings
from .models import Category


def _category_names(db: Session, business_id: int) -> list[str]:
    return list(db.scalars(
        select(Category.name).where(
            Category.business_id == business_id,
            Category.status == "active",
        )
    ).all())


def _local_parse(message: str, db: Session, business_id: int) -> dict[str, Any]:
    """Small deterministic fallback for local development and tests."""
    text = message.strip()
    lower = text.lower()

    amount_match = re.search(r"(?:ksh|kes|sh)?\s*([0-9][0-9,]*(?:\.\d{1,2})?)", lower)
    amount = Decimal(amount_match.group(1).replace(",", "")) if amount_match else None

    income_words = ("sold", "sale", "received", "earned", "income", "customer paid", "paid me")
    transaction_type = "INCOME" if any(word in lower for word in income_words) else "EXPENSE"

    payment_method = None
    if "m-pesa" in lower or "mpesa" in lower:
        payment_method = "M-Pesa"
    elif "cash" in lower:
        payment_method = "Cash"
    elif "bank" in lower:
        payment_method = "Bank"
    elif "card" in lower:
        payment_method = "Card"

    names = _category_names(db, business_id)
    category = None
    candidates = {
        "stock": "Stock",
        "rent": "Rent",
        "transport": "Transport",
        "electricity": "Electricity",
        "water": "Water",
        "internet": "Internet",
        "airtime": "Airtime",
        "salary": "Salaries",
        "salaries": "Salaries",
        "marketing": "Marketing",
        "repair": "Repairs",
        "supplies": "Supplies",
        "bank charge": "Bank Charges",
        "service": "Service Income",
        "sold": "Sales",
        "sale": "Sales",
    }
    for needle, name in candidates.items():
        if needle in lower and name in names:
            category = name
            break

    if not category:
        defaults = ["Sales", "Other Income"] if transaction_type == "INCOME" else ["Other Expenses"]
        category = next((x for x in defaults if x in names), None)

    confidence = 0.45
    if amount is not None:
        confidence += 0.2
    if category:
        confidence += 0.15
    if payment_method:
        confidence += 0.1

    return {
        "transaction_type": transaction_type,
        "amount": str(amount) if amount is not None else None,
        "category_name": category,
        "transaction_date": date.today().isoformat(),
        "description": text[:500],
        "payment_method": payment_method,
        "confidence": min(confidence, 0.9),
        "needs_clarification": amount is None,
        "clarification_question": "What amount should I record?" if amount is None else None,
    }


def _openai_parse(message: str, db: Session, business_id: int) -> dict[str, Any]:
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured")

    from openai import OpenAI

    categories = _category_names(db, business_id)
    client = OpenAI(api_key=settings.openai_api_key)

    schema = {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "transaction_type": {"type": "string", "enum": ["INCOME", "EXPENSE"]},
            "amount": {"type": ["string", "null"]},
            "category_name": {"type": ["string", "null"]},
            "transaction_date": {"type": "string"},
            "description": {"type": "string"},
            "payment_method": {"type": ["string", "null"]},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
            "needs_clarification": {"type": "boolean"},
            "clarification_question": {"type": ["string", "null"]},
        },
        "required": [
            "transaction_type", "amount", "category_name", "transaction_date",
            "description", "payment_method", "confidence",
            "needs_clarification", "clarification_question"
        ],
    }

    prompt = f"""
You extract ONE business transaction proposal for BizMoney Tracker.
Today is {date.today().isoformat()}.
Allowed business categories are: {json.dumps(categories)}.
Never invent an amount. If amount is missing, set amount to null and needs_clarification=true.
Choose only an allowed category name, or null when uncertain.
Income means money received by the business; expense means money spent by the business.
Keep description short and factual. Do not provide accounting or tax advice.
User message: {message}
""".strip()

    response = client.responses.create(
        model=settings.openai_model,
        input=prompt,
        text={
            "format": {
                "type": "json_schema",
                "name": "bizmoney_transaction_proposal",
                "strict": True,
                "schema": schema,
            }
        },
    )
    return json.loads(response.output_text)


def parse_transaction_message(message: str, db: Session, business_id: int) -> dict[str, Any]:
    if settings.ai_provider.lower() == "openai":
        return _openai_parse(message, db, business_id)
    return _local_parse(message, db, business_id)
