from .conftest import csrf

def register(client, email="owner@example.com"):
    return client.post("/api/auth/register", json={
        "full_name": "Test Owner",
        "email": email,
        "password": "StrongPass123"
    })

def create_business(client, name="ABC Shop"):
    return client.post(
        "/api/businesses",
        headers=csrf(client),
        json={
            "business_name": name,
            "business_type": "Retail",
            "country": "Kenya",
            "currency": "KES"
        }
    )

def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_registration_business_transaction_dashboard(client):
    r = register(client)
    assert r.status_code == 200
    assert client.cookies.get("bizmoney_session")

    business = create_business(client)
    assert business.status_code == 200
    business_id = business.json()["id"]

    cats = client.get(f"/api/categories?business_id={business_id}")
    assert cats.status_code == 200
    sales_category = next(c for c in cats.json() if c["name"] == "Sales")
    stock_category = next(c for c in cats.json() if c["name"] == "Stock")

    income = client.post(
        "/api/transactions",
        headers=csrf(client),
        json={
            "business_id": business_id,
            "category_id": sales_category["id"],
            "transaction_type": "INCOME",
            "amount": "5000.00",
            "transaction_date": "2026-09-03",
            "description": "Sales",
            "payment_method": "M-Pesa",
            "source": "MANUAL"
        }
    )
    assert income.status_code == 200

    expense = client.post(
        "/api/transactions",
        headers=csrf(client),
        json={
            "business_id": business_id,
            "category_id": stock_category["id"],
            "transaction_type": "EXPENSE",
            "amount": "1500.00",
            "transaction_date": "2026-09-03",
            "description": "Stock",
            "payment_method": "Cash",
            "source": "MANUAL"
        }
    )
    assert expense.status_code == 200

    dash = client.get(f"/api/dashboard?business_id={business_id}")
    assert dash.status_code == 200
    data = dash.json()
    assert float(data["total_sales"]) == 5000.0
    assert float(data["total_expenses"]) == 1500.0
    assert float(data["net_profit"]) == 3500.0

def test_business_data_isolation(client):
    register(client, "one@example.com")
    b1 = create_business(client, "One Shop").json()["id"]

    client.post("/api/auth/logout")
    register(client, "two@example.com")

    forbidden = client.get(f"/api/categories?business_id={b1}")
    assert forbidden.status_code == 403
