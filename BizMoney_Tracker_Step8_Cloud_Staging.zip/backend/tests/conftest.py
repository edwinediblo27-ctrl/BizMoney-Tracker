import os

os.environ["DATABASE_URL"] = "sqlite:///./test_bizmoney.db"
os.environ["JWT_SECRET"] = "test-secret"
os.environ["COOKIE_SECURE"] = "false"

import pytest
from fastapi.testclient import TestClient

from app.database import Base, engine
from app.main import app

@pytest.fixture(autouse=True)
def reset_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c

def csrf(client):
    token = client.cookies.get("bizmoney_csrf")
    return {"X-CSRF-Token": token} if token else {}
