from .conftest import csrf


def setup_business(client):
    client.post("/api/auth/register", json={
        "full_name": "AI Test Owner",
        "email": "ai@example.com",
        "password": "StrongPass123",
    })
    business = client.post(
        "/api/businesses",
        headers=csrf(client),
        json={
            "business_name": "AI Shop",
            "business_type": "Retail",
            "country": "Kenya",
            "currency": "KES",
        },
    ).json()
    return business["id"]


def test_ai_proposal_requires_confirmation(client):
    business_id = setup_business(client)

    before = client.get(f"/api/dashboard?business_id={business_id}").json()
    assert float(before["total_expenses"]) == 0

    proposal = client.post(
        "/api/ai/proposals",
        headers=csrf(client),
        json={
            "business_id": business_id,
            "message": "I bought stock for KSh 8,500 today through M-Pesa.",
        },
    )
    assert proposal.status_code == 200
    data = proposal.json()
    assert data["status"] == "PENDING"
    assert float(data["amount"]) == 8500.0
    assert data["category_name"] == "Stock"

    still_before = client.get(f"/api/dashboard?business_id={business_id}").json()
    assert float(still_before["total_expenses"]) == 0

    confirmed = client.post(
        f"/api/ai/proposals/{data['id']}/confirm",
        headers=csrf(client),
    )
    assert confirmed.status_code == 200

    after = client.get(f"/api/dashboard?business_id={business_id}").json()
    assert float(after["total_expenses"]) == 8500.0


def test_incomplete_ai_proposal_cannot_be_confirmed(client):
    business_id = setup_business(client)
    proposal = client.post(
        "/api/ai/proposals",
        headers=csrf(client),
        json={"business_id": business_id, "message": "I paid for transport today."},
    ).json()
    assert proposal["needs_clarification"] is True

    confirmed = client.post(
        f"/api/ai/proposals/{proposal['id']}/confirm",
        headers=csrf(client),
    )
    assert confirmed.status_code == 400
