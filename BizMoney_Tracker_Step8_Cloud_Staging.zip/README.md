# BizMoney Tracker — Step 7 AI Assistant Build

This package extends the staging build with a safe AI-assisted transaction-entry workflow.

## What Step 6 adds

- One combined project structure
- PostgreSQL database
- FastAPI backend
- Next.js frontend
- HttpOnly cookie authentication
- Basic CSRF protection for authenticated write requests
- Business-level authorization
- Category validation
- Alembic database migrations
- Basic automated backend tests
- Dockerfiles for backend and frontend
- Docker Compose for local/staging-style execution
- Health checks
- Environment variable templates
- Staging deployment checklist


## Step 7 — AI Assistant

The AI Assistant now supports:

- Natural-language transaction messages
- Structured transaction proposals
- Category matching against the business's real categories
- Amount, date and payment-method extraction
- Confidence display
- Clarification when essential information is missing
- Explicit Confirm or Cancel
- No database transaction is created until Confirm is clicked
- Confirmed AI entries are stored with source `AI_TEXT`

### AI modes

For local development, `AI_PROVIDER=local` uses a small deterministic parser so the feature can be tested without API costs.

For real AI parsing, configure:

```text
AI_PROVIDER=openai
OPENAI_API_KEY=your_secret_key
OPENAI_MODEL=gpt-5.6-luna
```

Keep the API key only on the backend. Never put it in the Next.js browser environment.

## Project structure

```text
BizMoney_Tracker_Step6_Staging/
├── backend/
│   ├── app/
│   ├── alembic/
│   ├── tests/
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── app/
│   ├── components/
│   ├── lib/
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml
└── README.md
```

# Fastest local test with Docker

Requirements:
- Docker Desktop

From this folder:

```bash
docker compose up --build
```

Then open:

- BizMoney frontend: http://localhost:3000
- FastAPI documentation: http://localhost:8000/docs
- Backend health: http://localhost:8000/health

## First-use flow

1. Open http://localhost:3000
2. Create an account.
3. Create a business.
4. Add an income transaction.
5. Add an expense transaction.
6. Return to Dashboard.
7. Confirm totals update.
8. Open Transactions and confirm both records are stored.

# Run without Docker

## Backend

Create `backend/.env` from `backend/.env.example`.

Start PostgreSQL separately, then:

```bash
cd backend
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Install:

```bash
pip install -r requirements.txt
```

Run migrations:

```bash
alembic upgrade head
```

Start API:

```bash
uvicorn app.main:app --reload
```

## Frontend

In another terminal:

```bash
cd frontend
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

# Authentication changes in Step 6

Step 5 stored the token in browser localStorage for development simplicity.

Step 6 changes this to:

- HttpOnly authentication cookie
- SameSite cookie controls
- Secure-cookie option for HTTPS environments
- CSRF token cookie + `X-CSRF-Token` header for authenticated write requests
- Explicit logout endpoint

This is a stronger staging foundation, although a full security review is still required before public production use.

# Database migrations

Alembic is included.

Create a new migration later with:

```bash
cd backend
alembic revision --autogenerate -m "describe change"
alembic upgrade head
```

# Run tests

From `backend`:

```bash
pytest
```

The included tests cover:
- health endpoint
- registration
- business creation
- category creation
- transaction entry
- dashboard totals
- business data isolation

# Staging deployment checklist

Before putting real customers on BizMoney:

- Use a managed PostgreSQL database.
- Generate a long random JWT secret.
- Set `COOKIE_SECURE=true` when using HTTPS.
- Set a real frontend origin.
- Store secrets only in the cloud provider's secret/environment manager.
- Run `alembic upgrade head` during deployment.
- Enable database backups.
- Add error monitoring.
- Add server logs and alerting.
- Add email verification.
- Add password reset.
- Add login rate limiting.
- Add refresh/revocation strategy.
- Add stronger audit logging.
- Add automated frontend tests.
- Add dependency/security scanning.
- Add a privacy policy and terms before accepting public customer data.

# What is not included yet

Step 6 intentionally does not include:
- AI transaction parsing
- receipt OCR
- voice input
- payments/subscriptions
- affiliate commissions
- M-Pesa automatic import
- bank integration
- tax filing
- eTIMS integration

Those should be added after the staging core is stable.

# Next recommended step

Step 8: cloud deployment and private staging release.

That stage can add the flow:

```text
User message
→ AI parses transaction
→ BizMoney validates proposal
→ User confirms
→ transaction is saved
```

The AI should never silently insert or modify financial records.


---

# Step 8 Cloud Staging

This version adds a Render Blueprint (`render.yaml`) and `DEPLOY_RENDER.md`.

Recommended staging architecture:

`Next.js frontend → FastAPI backend → managed PostgreSQL`

The frontend proxies `/api` calls to the backend, allowing the browser to use one origin for the application and authentication cookies.

For the full deployment procedure, read `DEPLOY_RENDER.md`.
