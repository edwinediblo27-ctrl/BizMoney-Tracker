"use client";

import { useState } from "react";
import { api } from "../lib/api";

function money(value, currency = "KES") {
  if (value === null || value === undefined) return "Not detected";
  try {
    return new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency,
      maximumFractionDigits: 2,
    }).format(Number(value));
  } catch {
    return `${currency} ${Number(value).toLocaleString()}`;
  }
}

export default function AIAssistant({ businessId, currency = "KES", onConfirmed }) {
  const [message, setMessage] = useState("");
  const [proposal, setProposal] = useState(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  async function ask(e) {
    e.preventDefault();
    if (!message.trim()) return;

    setBusy(true);
    setNotice("");
    setProposal(null);

    try {
      const result = await api("/api/ai/proposals", {
        method: "POST",
        body: JSON.stringify({ business_id: businessId, message: message.trim() }),
      });
      setProposal(result);
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function confirm() {
    if (!proposal) return;
    setBusy(true);
    setNotice("");
    try {
      await api(`/api/ai/proposals/${proposal.id}/confirm`, { method: "POST" });
      setNotice("Transaction recorded successfully.");
      setProposal(null);
      setMessage("");
      await onConfirmed();
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function reject() {
    if (!proposal) return;
    setBusy(true);
    setNotice("");
    try {
      await api(`/api/ai/proposals/${proposal.id}/reject`, { method: "POST" });
      setProposal(null);
      setNotice("Proposal cancelled. Nothing was recorded.");
    } catch (err) {
      setNotice(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="panel ai-panel">
      <div className="eyebrow">BizMoney AI</div>
      <h2>Tell me what happened</h2>
      <p className="muted">
        Describe one sale or expense. BizMoney will prepare a proposal for you to review before anything is saved.
      </p>

      <div className="ai-examples">
        <button type="button" onClick={() => setMessage("I bought stock for KSh 8,500 today through M-Pesa.")}>Bought stock</button>
        <button type="button" onClick={() => setMessage("I sold goods worth KSh 5,000 today through M-Pesa.")}>Made a sale</button>
        <button type="button" onClick={() => setMessage("I spent KSh 2,000 on transport today in cash.")}>Transport expense</button>
      </div>

      <form onSubmit={ask} className="ai-form">
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          maxLength={1200}
          placeholder="Example: I bought stock for KSh 8,500 today through M-Pesa."
          rows={4}
        />
        <button className="btn primary" disabled={busy || !message.trim()}>
          {busy ? "Working..." : "Create proposal"}
        </button>
      </form>

      {notice && <div className="notice ai-notice">{notice}</div>}

      {proposal && (
        <div className="proposal-card">
          <div className="proposal-head">
            <div>
              <div className="eyebrow">Review Before Recording</div>
              <h3>{proposal.transaction_type === "INCOME" ? "Income" : "Expense"} proposal</h3>
            </div>
            <span className="confidence">Confidence {Math.round(Number(proposal.confidence || 0) * 100)}%</span>
          </div>

          <div className="proposal-grid">
            <div><span>Amount</span><strong>{money(proposal.amount, currency)}</strong></div>
            <div><span>Category</span><strong>{proposal.category_name || "Not detected"}</strong></div>
            <div><span>Date</span><strong>{proposal.transaction_date || "Not detected"}</strong></div>
            <div><span>Payment</span><strong>{proposal.payment_method || "Not specified"}</strong></div>
          </div>

          <div className="proposal-description">
            <span>Description</span>
            <p>{proposal.description}</p>
          </div>

          {proposal.needs_clarification && (
            <div className="warning-box">
              {proposal.clarification_question || "This proposal is incomplete. Please enter the transaction manually instead."}
            </div>
          )}

          <div className="proposal-actions">
            <button className="btn primary" onClick={confirm} disabled={busy || proposal.needs_clarification}>
              Record Transaction
            </button>
            <button className="btn" onClick={reject} disabled={busy}>Cancel</button>
          </div>

          <p className="fine-print">Nothing is recorded until you choose “Record Transaction”.</p>
        </div>
      )}
    </section>
  );
}
