"use client";

export default function Sidebar({ section, setSection, onLogout }) {
  const items = [
    ["dashboard", "🏠", "Dashboard"],
    ["income", "💰", "Income"],
    ["expense", "💸", "Expenses"],
    ["transactions", "📋", "Transactions"],
    ["ai", "✨", "AI Assistant"],
  ];

  return (
    <aside className="sidebar">
      <div className="logo side-logo">Biz<span>Money</span></div>
      <nav>
        {items.map(([id, icon, label]) => (
          <button key={id}
            className={section === id ? "active" : ""}
            onClick={() => setSection(id)}>
            <span>{icon}</span>{label}
          </button>
        ))}
      </nav>
      <button className="logout-btn" onClick={onLogout}>Sign out</button>
    </aside>
  );
}
