"use client";

import { useMemo, useState } from "react";
import { api } from "../lib/api";

export default function TransactionForm({ businessId, categories, type, onSaved }) {
  const allowed = useMemo(
    () => categories.filter((c) => c.type === type),
    [categories, type]
  );

  const blank = () => ({
    amount: "",
    category_id: "",
    transaction_date: new Date().toISOString().slice(0, 10),
    description: "",
    payment_method: "M-Pesa",
  });

  const [form, setForm] = useState(blank());
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setMessage("");

    if (!form.category_id) {
      setMessage("Please select a category.");
      return;
    }

    setBusy(true);

    try {
      await api("/api/transactions", {
        method: "POST",
        body: JSON.stringify({
          business_id: businessId,
          category_id: Number(form.category_id),
          transaction_type: type,
          amount: form.amount,
          transaction_date: form.transaction_date,
          description: form.description,
          payment_method: form.payment_method,
          source: "MANUAL",
        }),
      });

      setMessage(type === "INCOME" ? "Income saved." : "Expense saved.");
      setForm(blank());
      await onSaved();
    } catch (err) {
      setMessage(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="panel">
      <div className="eyebrow">{type === "INCOME" ? "Money In" : "Money Out"}</div>
      <h2>{type === "INCOME" ? "Add Income" : "Add Expense"}</h2>

      <form onSubmit={submit} className="form-grid">
        <label>Amount
          <input type="number" min="0.01" step="0.01" required
            value={form.amount}
            onChange={(e) => setForm({ ...form, amount: e.target.value })}
            placeholder="0.00" />
        </label>

        <label>Category
          <select required value={form.category_id}
            onChange={(e) => setForm({ ...form, category_id: e.target.value })}>
            <option value="">Choose category</option>
            {allowed.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </label>

        <label>Date
          <input type="date" required value={form.transaction_date}
            onChange={(e) => setForm({ ...form, transaction_date: e.target.value })} />
        </label>

        <label>Payment method
          <select value={form.payment_method}
            onChange={(e) => setForm({ ...form, payment_method: e.target.value })}>
            <option>M-Pesa</option>
            <option>Cash</option>
            <option>Bank</option>
            <option>Card</option>
            <option>Other</option>
          </select>
        </label>

        <label className="span-2">Description
          <input value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder={type === "INCOME" ? "What did you sell?" : "What did you spend on?"} />
        </label>

        {message && <div className="notice span-2">{message}</div>}

        <div className="span-2">
          <button className="btn primary" disabled={busy}>
            {busy ? "Saving..." : type === "INCOME" ? "Save Income" : "Save Expense"}
          </button>
        </div>
      </form>
    </section>
  );
}
