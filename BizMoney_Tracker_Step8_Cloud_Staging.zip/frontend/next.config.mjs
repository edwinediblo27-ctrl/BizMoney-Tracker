const rawBackend = process.env.BACKEND_INTERNAL_URL || "http://127.0.0.1:8000";
const backend = rawBackend.startsWith("http://") || rawBackend.startsWith("https://")
  ? rawBackend
  : `http://${rawBackend}`;

/** @type {import('next').NextConfig} */
const nextConfig = {
  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: `${backend}/api/:path*`,
      },
      {
        source: "/health",
        destination: `${backend}/health`,
      },
    ];
  },
};

export default nextConfig;
