import "./globals.css";

export const metadata = {
  title: "BizMoney Tracker",
  description: "Know Your Money. Know Your Profit."
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
