"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, setBusinessId } from "../../lib/api";

export default function SetupPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    business_name: "",
    business_type: "Retail",
    country: "Kenya",
    currency: "KES",
  });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);

    try {
      const business = await api("/api/businesses", {
        method: "POST",
        body: JSON.stringify(form),
      });
      setBusinessId(business.id);
      router.push("/dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth-page">
      <div className="auth-card wide">
        <div className="logo">Biz<span>Money</span></div>
        <h1>Set up your business</h1>
        <p className="muted">You can change these details later.</p>

        <form onSubmit={submit} className="form-grid">
          <label>Business name
            <input required value={form.business_name}
              onChange={(e) => setForm({ ...form, business_name: e.target.value })}
              placeholder="e.g. ABC Shop" />
          </label>

          <label>Business type
            <select value={form.business_type}
              onChange={(e) => setForm({ ...form, business_type: e.target.value })}>
              <option>Retail</option>
              <option>Services</option>
              <option>Food & Hospitality</option>
              <option>Online Business</option>
              <option>Freelance / Consulting</option>
              <option>Other</option>
            </select>
          </label>

          <label>Country
            <input value={form.country}
              onChange={(e) => setForm({ ...form, country: e.target.value })} />
          </label>

          <label>Currency
            <select value={form.currency}
              onChange={(e) => setForm({ ...form, currency: e.target.value })}>
              <option value="KES">KES — Kenyan Shilling</option>
              <option value="USD">USD — US Dollar</option>
            </select>
          </label>

          {error && <div className="error span-2">{error}</div>}

          <div className="span-2">
            <button className="btn primary" disabled={busy}>
              {busy ? "Creating business..." : "Finish setup"}
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}
