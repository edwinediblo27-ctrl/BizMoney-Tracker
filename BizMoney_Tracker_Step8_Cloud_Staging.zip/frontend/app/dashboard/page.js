"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import Sidebar from "../../components/Sidebar";
import TransactionForm from "../../components/TransactionForm";
import AIAssistant from "../../components/AIAssistant";
import {
  api, clearLocalBusiness, getBusinessId, setBusinessId
} from "../../lib/api";

function money(value, currency = "KES") {
  const number = Number(value || 0);
  try {
    return new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency,
      maximumFractionDigits: 2,
    }).format(number);
  } catch {
    return `${currency} ${number.toLocaleString()}`;
  }
}

export default function DashboardPage() {
  const router = useRouter();
  const [section, setSection] = useState("dashboard");
  const [business, setBusiness] = useState(null);
  const [dashboard, setDashboard] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      setError("");

      await api("/api/auth/me");
      const businesses = await api("/api/businesses");

      if (!businesses.length) {
        router.replace("/setup");
        return;
      }

      const stored = getBusinessId();
      const selected = businesses.find((b) => b.id === stored) || businesses[0];

      setBusinessId(selected.id);
      setBusiness(selected);

      const [summary, txs, cats] = await Promise.all([
        api(`/api/dashboard?business_id=${selected.id}`),
        api(`/api/transactions?business_id=${selected.id}`),
        api(`/api/categories?business_id=${selected.id}`),
      ]);

      setDashboard(summary);
      setTransactions(txs);
      setCategories(cats);
    } catch (err) {
      if (/auth|session|401|expired/i.test(err.message)) {
        router.replace("/login");
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    load();
  }, [load]);

  async function logout() {
    try {
      await api("/api/auth/logout", { method: "POST" });
    } finally {
      clearLocalBusiness();
      router.push("/login");
    }
  }

  const categoryMap = useMemo(
    () => Object.fromEntries(categories.map((c) => [c.id, c.name])),
    [categories]
  );

  if (loading) {
    return <main className="center-page">Loading your business...</main>;
  }

  return (
    <div className="app-shell">
      <Sidebar section={section} setSection={setSection} onLogout={logout} />

      <main className="main-content">
        <header className="top-row">
          <div>
            <div className="eyebrow">BizMoney Tracker</div>
            <h1>{business?.business_name || "Your Business"}</h1>
            <p className="muted">Know Your Money. Know Your Profit.</p>
          </div>
          <div className="business-chip">
            {business?.currency || "KES"} · {business?.country || "Kenya"}
          </div>
        </header>

        {error && <div className="error page-error">{error}</div>}

        {section === "dashboard" && (
          <>
            <div className="metric-grid">
              <Metric label="Total Sales" value={money(dashboard?.total_sales, business?.currency)} />
              <Metric label="Expenses" value={money(dashboard?.total_expenses, business?.currency)} />
              <Metric label="Net Profit"
                value={money(dashboard?.net_profit, business?.currency)}
                tone={Number(dashboard?.net_profit) >= 0 ? "green" : "red"} />
              <Metric label="Cash Flow"
                value={money(dashboard?.cash_flow, business?.currency)}
                tone={Number(dashboard?.cash_flow) >= 0 ? "green" : "red"} />
            </div>

            <section className="panel">
              <div className="panel-head">
                <div>
                  <div className="eyebrow">Latest Activity</div>
                  <h2>Recent Transactions</h2>
                </div>
                <button className="btn" onClick={load}>Refresh</button>
              </div>
              <TransactionTable
                transactions={transactions.slice(0, 8)}
                categoryMap={categoryMap}
                currency={business?.currency}
              />
            </section>
          </>
        )}

        {section === "income" && business && (
          <TransactionForm
            businessId={business.id}
            categories={categories}
            type="INCOME"
            onSaved={load}
          />
        )}

        {section === "expense" && business && (
          <TransactionForm
            businessId={business.id}
            categories={categories}
            type="EXPENSE"
            onSaved={load}
          />
        )}

        {section === "ai" && business && (
          <AIAssistant
            businessId={business.id}
            currency={business.currency}
            onConfirmed={load}
          />
        )}

        {section === "transactions" && (
          <section className="panel">
            <div className="eyebrow">Records</div>
            <h2>All Transactions</h2>
            <TransactionTable
              transactions={transactions}
              categoryMap={categoryMap}
              currency={business?.currency}
            />
          </section>
        )}
      </main>
    </div>
  );
}

function Metric({ label, value, tone = "" }) {
  return (
    <div className="metric-card">
      <span>{label}</span>
      <strong className={tone}>{value}</strong>
    </div>
  );
}

function TransactionTable({ transactions, categoryMap, currency }) {
  if (!transactions.length) {
    return <div className="empty">No transactions yet. Add your first income or expense.</div>;
  }

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Description</th>
            <th>Category</th>
            <th>Method</th>
            <th className="right">Amount</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((tx) => {
            const income = tx.transaction_type === "INCOME";
            return (
              <tr key={tx.id}>
                <td>{tx.transaction_date}</td>
                <td>{tx.description || "—"}</td>
                <td>{categoryMap[tx.category_id] || "Category"}</td>
                <td>{tx.payment_method || "—"}</td>
                <td className={`right ${income ? "green" : "red"}`}>
                  {income ? "+" : "-"}{money(tx.amount, currency)}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
